package org.bdj;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.util.ArrayList;
import org.havi.ui.HComponent;

/**
 * Screen.java — HENloader MX custom display
 * mansoor0x · 2026
 *
 * Dark terminal aesthetic:
 *   Background : #020409  (near-black blue)
 *   Text       : #B8CCE0  (cold grey-blue)
 *   Success    : #00C896  (teal green)
 *   Warning    : #F0A030  (amber)
 *   Error      : #E04040  (red)
 *   Accent     : #0057E0  (PS blue)
 *   Dim        : #3A5575
 */
public class Screen extends HComponent {

    /* ── Colour palette ── */
    private static final Color BG        = new Color(0x02, 0x04, 0x09);
    private static final Color BG_PANEL  = new Color(0x06, 0x0A, 0x12);
    private static final Color BORDER    = new Color(0x0D, 0x18, 0x25);
    private static final Color TEXT      = new Color(0xB8, 0xCC, 0xE0);
    private static final Color DIM       = new Color(0x3A, 0x55, 0x75);
    private static final Color SUCCESS   = new Color(0x00, 0xC8, 0x96);
    private static final Color WARNING   = new Color(0xF0, 0xA0, 0x30);
    private static final Color ERROR_COL = new Color(0xE0, 0x40, 0x40);
    private static final Color ACCENT    = new Color(0x00, 0x57, 0xE0);
    private static final Color BRIGHT    = new Color(0xE8, 0xF4, 0xFF);

    /* ── Layout ── */
    private static final int PAD_X  = 40;
    private static final int PAD_Y  = 30;
    private static final int LINE_H = 20;

    /* ── Fonts ── */
    private static final Font FONT_BODY    = new Font("Monospaced", Font.PLAIN,  14);
    private static final Font FONT_BOLD    = new Font("Monospaced", Font.BOLD,   14);
    private static final Font FONT_TITLE   = new Font("Monospaced", Font.BOLD,   20);
    private static final Font FONT_LABEL   = new Font("Monospaced", Font.PLAIN,  11);

    private final ArrayList messages;
    public int top = 0;   /* scroll offset */

    public Screen(ArrayList messages) {
        this.messages = messages;
    }

    @Override
    public void paint(Graphics g) {
        int W = getWidth();
        int H = getHeight();

        /* ── Background ── */
        g.setColor(BG);
        g.fillRect(0, 0, W, H);

        /* ── Scanline effect (subtle horizontal lines) ── */
        g.setColor(new Color(0, 0, 0, 18));
        for (int y = 0; y < H; y += 4) {
            g.drawLine(0, y, W, y);
        }

        /* ── Top bar ── */
        g.setColor(BG_PANEL);
        g.fillRect(0, 0, W, 52);
        g.setColor(BORDER);
        g.drawLine(0, 52, W, 52);

        /* Title left */
        g.setFont(FONT_TITLE);
        g.setColor(ACCENT);
        g.drawString("HENloader", PAD_X, 34);
        g.setColor(BRIGHT);
        g.drawString(" MX", PAD_X + getFontMetrics(FONT_TITLE).stringWidth("HENloader"), 34);

        /* Version right */
        g.setFont(FONT_LABEL);
        g.setColor(DIM);
        String verStr = "mansoor0x  ·  v1.0";
        int vw = getFontMetrics(FONT_LABEL).stringWidth(verStr);
        g.drawString(verStr, W - PAD_X - vw, 34);

        /* ── Left panel border ── */
        int panelW = (int)(W * 0.68);
        g.setColor(BORDER);
        g.drawRect(PAD_X - 10, 62, panelW, H - 80);
        g.setColor(BG_PANEL);
        g.fillRect(PAD_X - 9, 63, panelW - 1, H - 82);

        /* ── Right info panel ── */
        int rpX = PAD_X + panelW + 20;
        int rpW = W - rpX - PAD_X;
        g.setColor(BG_PANEL);
        g.fillRect(rpX - 10, 62, rpW + 20, H - 80);
        g.setColor(BORDER);
        g.drawRect(rpX - 10, 62, rpW + 20, H - 80);

        drawRightPanel(g, rpX, H);

        /* ── Log text ── */
        synchronized (messages) {
            g.setFont(FONT_BODY);
            FontMetrics fm = getFontMetrics(FONT_BODY);

            int maxLines = (H - 100) / LINE_H;
            int startIdx = Math.max(0, messages.size() - maxLines - top / LINE_H);
            int endIdx   = Math.min(messages.size(), startIdx + maxLines);

            int y = 80;
            for (int i = startIdx; i < endIdx; i++) {
                String line = (String) messages.get(i);
                Color col   = colorForLine(line);
                g.setColor(col);
                g.drawString(line, PAD_X, y);
                y += LINE_H;
            }
        }

        /* ── Bottom bar ── */
        g.setColor(BG_PANEL);
        g.fillRect(0, H - 30, W, 30);
        g.setColor(BORDER);
        g.drawLine(0, H - 30, W, H - 30);

        g.setFont(FONT_LABEL);
        g.setColor(DIM);
        g.drawString("▲▼ scroll  ·  X = run exploit  ·  FW 9.00 – 13.52", PAD_X, H - 10);

        /* ── Ambient glow at top ── */
        for (int r = 1; r <= 6; r++) {
            int alpha = 6 - r;
            g.setColor(new Color(0, 87, 224, alpha * 4));
            g.fillOval(W / 2 - r * 80, -r * 20, r * 160, r * 60);
        }
    }

    /* ── Right panel: controls + status ── */
    private void drawRightPanel(Graphics g, int rx, int H) {
        int y = 90;
        g.setFont(FONT_LABEL);

        /* Label */
        g.setColor(DIM);
        String lbl = "CONTROLS";
        g.drawString(lbl, rx, y);
        g.setColor(BORDER);
        g.drawLine(rx, y + 4, rx + 140, y + 4);
        y += 22;

        String[][] ctrls = {
            { "X",       "Run exploit" },
            { "O",       "Alt chain"   },
            { "▲",       "Scroll up"   },
            { "▼",       "Scroll down" },
        };

        for (String[] c : ctrls) {
            g.setFont(FONT_BOLD);
            g.setColor(ACCENT);
            g.drawString(c[0], rx, y);
            g.setFont(FONT_BODY);
            g.setColor(TEXT);
            g.drawString(c[1], rx + 24, y);
            y += LINE_H;
        }

        y += 16;

        /* Status section */
        g.setFont(FONT_LABEL);
        g.setColor(DIM);
        g.drawString("FIRMWARE SUPPORT", rx, y);
        g.setColor(BORDER);
        g.drawLine(rx, y + 4, rx + 140, y + 4);
        y += 22;

        String[][] fws = {
            { "9.00",  "Lapse+Poops" },
            { "10.x",  "Lapse+Poops" },
            { "11.x",  "Lapse+Poops" },
            { "12.02", "Lapse+Poops" },
            { "12.50", "Poops" },
            { "12.52", "Poops" },
            { "13.00", "Poops  +" },
            { "13.02", "Poops  +" },
            { "13.04", "Poops  +" },
            { "13.50", "Poops  +" },
            { "13.52", "Poops  +" },
        };

        for (String[] fw : fws) {
            g.setFont(FONT_BODY);
            boolean isNew = fw[0].startsWith("13.");
            g.setColor(isNew ? SUCCESS : TEXT);
            g.drawString(fw[0], rx, y);
            g.setColor(isNew ? WARNING : DIM);
            g.drawString(fw[1], rx + 52, y);
            y += LINE_H - 2;
        }
    }

    /* ── Colour-code log lines by content ── */
    private static Color colorForLine(String line) {
        if (line == null || line.isEmpty()) return TEXT;
        if (line.startsWith("╔") || line.startsWith("║") || line.startsWith("╚"))
            return ACCENT;
        if (line.contains("SUCCESS") || line.contains("success") || line.startsWith("[+]"))
            return SUCCESS;
        if (line.startsWith("[!]") || line.contains("FAILED") || line.contains("fatal"))
            return ERROR_COL;
        if (line.startsWith("[*]"))
            return WARNING;
        if (line.startsWith("──") || line.startsWith("  X") || line.startsWith("  O"))
            return DIM;
        if (line.contains("mansoor0x"))
            return BRIGHT;
        if (line.startsWith("    "))
            return ACCENT;
        return TEXT;
    }
}
