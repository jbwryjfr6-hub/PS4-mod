package org.bdj.network;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import org.bdj.payload.PayloadLoader;

/**
 * NetLoader.java — HENloader MX
 * mansoor0x · 2026
 *
 * TCP payload receiver.
 * When USB payload is not found, listens on port 9090 for
 * a raw binary sent from a PC on the same network.
 *
 * PC side (Python):
 *   import socket
 *   s = socket.socket()
 *   s.connect(("PS4_IP", 9090))
 *   s.sendall(open("GoldHEN.bin","rb").read())
 *   s.close()
 *
 * Or use netcat:
 *   nc PS4_IP 9090 < GoldHEN.bin
 *
 * Timeout: 30 seconds
 */
public class NetLoader {

    private static final int PORT        = 9090;
    private static final int TIMEOUT_MS  = 30000;
    private static final int MAX_SIZE    = 4 * 1024 * 1024;

    public static int load(PrintStream out) {
        ServerSocket server = null;
        try {
            server = new ServerSocket(PORT);
            server.setSoTimeout(TIMEOUT_MS);

            String ip = getLocalIP();
            out.println("[NET] Listening on port " + PORT);
            out.println("[NET] PC: nc " + ip + " " + PORT + " < GoldHEN.bin");
            out.println("[NET] Waiting " + (TIMEOUT_MS/1000) + "s…");

            Socket client = server.accept();
            out.println("[NET] Connected from " +
                       client.getInetAddress().getHostAddress());

            InputStream is = client.getInputStream();

            // Send ACK byte to signal ready
            OutputStream os = client.getOutputStream();
            os.write(0x01);
            os.flush();

            int ret = PayloadLoader.loadStream(out, is, "network");

            client.close();
            server.close();
            return ret;

        } catch (java.net.SocketTimeoutException e) {
            out.println("[NET] Timeout — no payload received");
            return -4;
        } catch (Throwable t) {
            out.println("[NET] Error: " + t.getMessage());
            return -4;
        } finally {
            if (server != null) {
                try { server.close(); } catch (Throwable t2) {}
            }
        }
    }

    private static String getLocalIP() {
        try {
            return InetAddress.getLocalHost().getHostAddress();
        } catch (Throwable t) {
            return "PS4_IP";
        }
    }
}
