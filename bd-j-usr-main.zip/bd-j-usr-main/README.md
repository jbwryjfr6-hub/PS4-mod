# HENloader MX

<div align="center">

![Platform](https://img.shields.io/badge/Platform-PlayStation%204-003087?style=for-the-badge&logo=playstation&logoColor=white)
![Firmware](https://img.shields.io/badge/Firmware-9.00%20–%2013.52-00c896?style=for-the-badge)
![Language](https://img.shields.io/badge/Language-Java%20BD--J-f89820?style=for-the-badge&logo=java&logoColor=white)
![License](https://img.shields.io/badge/License-GPL--2.0-555?style=for-the-badge)
![Author](https://img.shields.io/badge/Author-mansoor0x-0057e0?style=for-the-badge)

**PS4 Blu-ray Disc Java exploit loader — firmware 9.00 through 13.52**

*Based on [HENloader LP](https://github.com/iaceene/HENloader_Source) by iaceene*

</div>

---

## Overview

HENloader MX is a BD-J (Blu-ray Disc Java) based exploit chain for the PlayStation 4.
It runs directly from a burned Blu-ray disc — no network connection, no USB exploit host required.

The disc boots the PS4's Java runtime, escapes the BD-J sandbox, executes the exploit chain
(Lapse or Poops depending on firmware), performs privilege escalation, patches the kernel,
then loads the GoldHEN payload from USB or the local network.

This fork extends the original HENloader LP with:
- Firmware 13.00 / 13.02 / 13.04 / 13.50 / 13.52 support
- Reworked dark terminal UI
- Three-path sandbox escape (reflection → ClassLoader → Unsafe)
- Network payload receiver (TCP port 9090) as USB fallback
- Modular Java architecture

---

## Firmware Compatibility

| Firmware | Exploit Chain | Sandbox Escape | Kernel Patches | Status |
|----------|:---:|:---:|:---:|:---:|
| 9.00 | Lapse + Poops | ✓ | ✓ | ✅ Stable |
| 9.20 – 9.60 | Lapse + Poops | ✓ | ✓ | ✅ Stable |
| 10.00 – 10.01 | Lapse + Poops | ✓ | ✓ | ✅ Stable |
| 10.20 – 10.60 | Lapse + Poops | ✓ | ✓ | ✅ Stable |
| 11.00 | Lapse + Poops | ✓ | ✓ | ✅ Stable |
| 11.50 – 11.52 | Lapse + Poops | ✓ | ✓ | ✅ Stable |
| 12.00 – 12.02 | Lapse + Poops | ✓ | ✓ | ✅ Stable |
| 12.50 – 12.52 | Poops | ✓ | ✓ | ✅ Stable |
| 13.00 | Poops | ✓ | ✓ | ✅ Stable |
| 13.02 – 13.04 | Poops | ✓ | ✓ | ✅ Proven on hardware |
| **13.50** | Poops | ✓ | ✓ | ✅ **New** |
| **13.52** | Poops | ✓ | ✓ | ✅ **New** |

> **Chain selection:** The Lapse chain (≤ 12.02) and Poops chain (≥ 9.00) are both available
> where applicable. The disc detects firmware automatically and presents the correct options.

---

## Architecture

```
HENloader-MX/
│
├── InitXlet.java                     Entry point · BD-J lifecycle · main loop
├── Screen.java                       Terminal UI · dark palette · scroll support
├── Helper.java                       Firmware detection · BD-J property reader
├── Kernel.java                       Kernel base detection · r/w coordinator
├── Lapse.java                        Lapse heap-UAF chain (FW ≤ 12.02)
├── DisableSecurityManagerAction.java Sandbox escape (3 escalation paths)
├── MessagesOutputStream.java         Console output → screen renderer
│
├── external/
│   ├── KernelOffset.java             Kernel RVAs for all supported firmware
│   └── Poops.java                    Poops IOV-overflow chain (FW ≤ 13.52)
│
├── sandbox/
│   └── SandboxEscape.java            Privilege escalation · allproc traverse · ucred patch
│
├── api/
│   ├── UnsafeHelper.java             sun.misc.Unsafe wrapper for native memory access
│   └── NativeHelper.java             PS4 BD-J native API bridge · kernel base scan
│
├── payload/
│   └── PayloadLoader.java            USB / disc / network payload loader
│
└── network/
    └── NetLoader.java                TCP receiver on port 9090 (USB fallback)
```

---

## Exploit Flow

```
BD-J Runtime
     │
     ▼
DisableSecurityManagerAction        ← reflection / ClassLoader / Unsafe
     │
     ▼ SecurityManager == null
     │
     ├── Lapse (FW ≤ 12.02)         ← heap UAF → Java r/w → native escalation
     │
     └── Poops (FW 9.00 – 13.52)   ← IOV overflow → pipe corruption → kernel r/w
             │
             ▼
     SandboxEscape.run()
             │
             ├── allproc traverse   ← find BD-J process by PID
             ├── ucred patch        ← uid=0, gid=0, prison=prison0
             └── kernel NOP patches ← sceSblACMgrHasMmapSelf, AuthMgr, vm_mmap
             │
             ▼
     PayloadLoader
             │
             ├── USB: /mnt/usb0/GoldHEN.bin
             ├── Disc: /bdmv/GoldHEN.bin
             └── Network: TCP :9090
```

---

## Key Kernel Offsets

### 13.x Firmware (new in this fork)

| Symbol | 13.00 / 13.02 / 13.04 | 13.50 / 13.52 |
|--------|-----------------------|--------------|
| `allproc` | `0x2475EF0` | `0x2485EF0` |
| `prison0` | `0x16D9500` | `0x16E9500` |
| `rootvnode` | `0x1EFF5A0` | `0x1F0F5A0` |
| `sysent` | `0x110A760` | **`0x1112470`** (+0x7D10) |
| `sceSblACMgrHasMmapSelf` | `0x10AD30` | `0x11AD30` |
| `sceSblAuthMgrVerifyHeader` | `0x90D30` | `0xA0D30` |

> The `sysent` table shifts by `+0x7D10` in firmware 13.50.
> This is the primary difference requiring dedicated 13.50/13.52 entries.
> All other offsets scale proportionally.

---

## Build

### Requirements

| Tool | Version | Notes |
|------|---------|-------|
| JDK | 8+ | Compiled with `-source 1.4 -target 1.4` |
| BD-J stubs | any | Place `.jar` stubs in `lib/` |
| make | any | Optional — `build.sh` also works |
| genisoimage | any | Optional — for ISO creation |

**BD-J stubs** — get from one of:
- `github.com/GoldHEN/henloader_lp` → `bd_stubs/`
- kimariin's BD-J build environment

### Compile

```bash
# Using make
make all

# Using shell script
chmod +x build.sh && ./build.sh

# Output
build/HENloader-MX.jar
```

### Build ISO

```bash
make iso
# → build/HENloader-MX.iso
# Burn with ImgBurn, Brasero, or cdrecord
```

---

## Usage

### 1 — Prepare payload

Copy `GoldHEN.bin` to the root of a FAT32 USB drive:

```
USB/
└── GoldHEN.bin
```

### 2 — Boot the disc

Insert the burned BD-R. The PS4 will auto-launch the BD-J application.

### 3 — Select chain

| Button | Action |
|--------|--------|
| **X** | Run exploit (Lapse on ≤ 12.02 · Poops on ≥ 12.50) |
| **O** | Force Poops chain |
| **▲** | Scroll log up |
| **▼** | Scroll log down |

### 4 — Network fallback (no USB)

If no USB payload is found, the disc listens on TCP port 9090.
From your PC:

```bash
# Python
python send_payload.py 192.168.1.100 GoldHEN.bin

# netcat
nc 192.168.1.100 9090 < GoldHEN.bin
```

---

## Log Output

Successful run (13.02 example):

```
╔══════════════════════════════════════╗
║      HENloader MX  v1.0             ║
║      by mansoor0x                   ║
╠══════════════════════════════════════╣
║  Based on HENloader LP by iaceene   ║
║  GoldHEN 2.4b18.7 by SiSTR0         ║
║  Poops exploit by theflow0          ║
║  Lapse exploit by Gezine            ║
╚══════════════════════════════════════╝

[+] Sandbox escaped successfully
[*] Firmware : 13.02
[+] Kernel offsets loaded for 13.02
[+] allproc  = 0x2475ef0
[+] prison0  = 0x16d9500
[+] sysent   = 0x110a760

── Select exploit ──────────────────────
  X = Poops  (only option for 13.02)
────────────────────────────────────────

[POOPS] Starting Poops exploit
[POOPS] Attempt 1/8
[POOPS] Stage 1: IOV workers setup
[POOPS] Stage 2: spray (512 objects)
[POOPS] Stage 3: OOB trigger
[POOPS] Stage 4: reclaim sockets
[POOPS] Stage 5: kernel r/w
[POOPS] kbase = 0xffffffff82000000
[POOPS] Stage 6: sandbox + patches
[SBX] ucred patched — uid=0 gid=0 prison=prison0
[SBX] sceSblACMgrHasMmapSelf NOPed
[SBX] sceSblAuthMgrVerifyHeader patched
[POOPS] Stage 7: loading payload
[PAYLOAD] Found: /mnt/usb0/GoldHEN.bin
[PAYLOAD] Read 499776 bytes from GoldHEN.bin
[PAYLOAD] Format: raw JMP-rel32
[PAYLOAD] Mapped @ 0xffffffff84000000
[PAYLOAD] Executing GoldHEN…

╔══════════════════════════════════════╗
║         EXPLOIT SUCCESS!             ║
║                                      ║
║  Chain  : Poops                      ║
║  FW     : 13.02                      ║
║  Author : mansoor0x                  ║
╚══════════════════════════════════════╝

[+] GoldHEN should now be active
[+] FTP / PKG install / Debug settings enabled

    mansoor0x — HENloader MX v1.0
```

---

## Credits

| Component | Author | Source |
|-----------|--------|--------|
| HENloader LP (original base) | iaceene | [GitHub](https://github.com/iaceene/HENloader_Source) |
| Poops exploit | theflow0 | Public research |
| Lapse exploit | Gezine | Public research |
| GoldHEN payload | SiSTR0 & GoldHEN team | [GitHub](https://github.com/GoldHEN/GoldHEN) |
| 13.x kernel offset research | Scene-Collective | [ps4-hen](https://github.com/Scene-Collective/ps4-hen) |
| pOOBs4 research | sleirsgoevy | Public research |
| HENloader MX port + 13.52 | **mansoor0x** | This repo |

---

## Technical References

- [PS4 BD-J Exploit Research](https://cturt.github.io/ps4.html) — CTurt
- [FreeBSD struct proc layout](https://github.com/freebsd/freebsd-src) — FreeBSD Project  
- [Scene-Collective ps4-hen](https://github.com/Scene-Collective/ps4-hen) — kernel offset database
- [PS4 Kernel Internals](https://github.com/idc/ps4-payload-sdk) — idc

---

## Disclaimer

This project is intended for **security research and homebrew development** on hardware you own.
The authors are not responsible for any misuse. All original exploit research credit belongs
to the respective authors listed above.

---

## License

GPL-2.0 — inherited from [HENloader LP](https://github.com/iaceene/HENloader_Source).

---

<div align="center">

**mansoor0x · 2026**

![visitors](https://visitor-badge.laobi.icu/badge?page_id=mansoor0x.henloader-mx)

</div>
