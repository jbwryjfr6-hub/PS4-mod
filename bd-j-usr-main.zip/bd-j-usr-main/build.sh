#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# build.sh — HENloader MX
# mansoor0x · 2026
#
# Requirements:
#   - JDK 8 or later
#   - BD-J / GEM stubs in lib/
#   - kimariin's BD-J build environment (see README)
#
# Usage:
#   chmod +x build.sh
#   ./build.sh
#
# Output:
#   out/HENloader-MX.jar   — BD-J xlet JAR
#   out/BDMV/              — BD disc structure (burn this)
# ═══════════════════════════════════════════════════════════════

set -e

VERSION="1.0"
AUTHOR="mansoor0x"
OUT_DIR="out"
SRC_DIR="."
LIB_DIR="lib"
CLASS_DIR="classes"

# ── Colours
GRN="\033[92m"; YEL="\033[93m"; RED="\033[91m"; RST="\033[0m"
ok()   { echo -e "${GRN}  ✓  $1${RST}"; }
warn() { echo -e "${YEL}  !  $1${RST}"; }
err()  { echo -e "${RED}  ✗  $1${RST}"; exit 1; }

echo ""
echo "  ╔══════════════════════════════════════╗"
echo "  ║    HENloader MX  v${VERSION}  — build      ║"
echo "  ║    by ${AUTHOR}                   ║"
echo "  ╚══════════════════════════════════════╝"
echo ""

# ── Check Java
command -v javac &>/dev/null || err "javac not found — install JDK"
JAVA_VER=$(javac -version 2>&1 | awk '{print $2}')
ok "javac ${JAVA_VER}"

# ── Check BD-J stubs
if [ ! -d "${LIB_DIR}" ]; then
    warn "lib/ not found — creating stub dir"
    mkdir -p "${LIB_DIR}"
    warn "Add BD-J/GEM JAR stubs to lib/ before compiling"
    warn "See: https://github.com/GoldHEN/henloader_lp — bd_stubs/"
fi

# ── Prepare dirs
rm -rf "${CLASS_DIR}" "${OUT_DIR}"
mkdir -p "${CLASS_DIR}" "${OUT_DIR}/BDMV/BACKUP"

# ── Collect sources
SOURCES=$(find "${SRC_DIR}" -name "*.java" | grep -v "^${CLASS_DIR}" | grep -v "^${OUT_DIR}")
SOURCE_COUNT=$(echo "$SOURCES" | wc -l)
ok "Found ${SOURCE_COUNT} Java source files"

# ── Compile
echo ""
echo "  Compiling..."
CLASSPATH="${LIB_DIR}/*:${CLASS_DIR}"

javac \
    -source 1.4 \
    -target 1.4 \
    -cp "${CLASSPATH}" \
    -d "${CLASS_DIR}" \
    ${SOURCES} 2>&1 || err "Compilation failed"

ok "Compiled to ${CLASS_DIR}/"

# ── Build JAR
echo ""
echo "  Packaging JAR..."
JAR_FILE="${OUT_DIR}/HENloader-MX.jar"

jar cf "${JAR_FILE}" -C "${CLASS_DIR}" .
ok "JAR → ${JAR_FILE}  ($(du -sh ${JAR_FILE} | cut -f1))"

# ── Copy BD-J disc structure
#    Assumes BDMV/ template exists in project root (from kimariin's env)
if [ -d "BDMV" ]; then
    cp -r BDMV/* "${OUT_DIR}/BDMV/"
    # Replace xlet JAR in disc structure
    cp "${JAR_FILE}" "${OUT_DIR}/BDMV/BDJO/00000.bdjo" 2>/dev/null || true
    ok "BD disc structure populated"
else
    warn "BDMV/ template not found — JAR only (no ISO)"
    warn "Get the BD template from kimariin's build environment"
fi

# ── Copy permission file
cp bluray.InitXlet.perm "${OUT_DIR}/" 2>/dev/null || true

echo ""
echo "  ─────────────────────────────────────────"
echo "  Build complete!"
echo ""
echo "  JAR  : ${OUT_DIR}/HENloader-MX.jar"
echo "  BDMV : ${OUT_DIR}/BDMV/"
echo ""
echo "  Next: burn BDMV/ structure to BD-R using ImgBurn"
echo "  ─────────────────────────────────────────"
echo ""
