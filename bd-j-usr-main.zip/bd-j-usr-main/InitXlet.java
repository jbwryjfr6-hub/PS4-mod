package org.bdj;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import javax.tv.xlet.XletContext;
import org.bdj.external.KernelOffset;
import org.bdj.external.Poops;
import org.dvb.event.UserEvent;
import org.dvb.event.UserEventRepository;
import org.havi.ui.HScene;

/**
 * InitXlet.java — HENloader MX
 * mansoor0x · 2026
 *
 * Based on HENloader LP by iaceene (GPL-2.0)
 * Extended with PS4 firmware 13.00 – 13.52 support.
 *
 * Firmware support:
 *   Lapse  chain : 9.00 – 12.02
 *   Poops  chain : 9.00 – 13.52
 *
 * Controls on-disc:
 *   X  = Lapse (where available) / Poops
 *   O  = Poops (where Lapse also available)
 *   ▲  = Scroll log up
 *   ▼  = Scroll log down
 */
public class InitXlet implements Xlet, UserEventListener {

    /* ── PS4 HID button codes ── */
    public static final int BUTTON_X       = 10;
    public static final int BUTTON_O       = 19;
    public static final int BUTTON_SQUARE  = 47;
    public static final int BUTTON_UP      = 38;
    public static final int BUTTON_DOWN    = 40;

    private static final String VERSION    = "1.0";
    private static final String AUTHOR     = "mansoor0x";

    private static InitXlet instance;
    private EventQueue eq;
    private HScene scene;
    private Screen gui;
    private XletContext context;
    public static PrintStream console;

    /* ── Simple synchronized event queue ── */
    public static class EventQueue {
        int cnt = 0;
        private final LinkedList l = new LinkedList();

        public synchronized void put(Object o) {
            l.addLast(o);
            cnt++;
        }

        public synchronized Object get() {
            if (cnt == 0) return null;
            Object o = l.getFirst();
            l.removeFirst();
            cnt--;
            return o;
        }
    }

    private static final ArrayList messages = new ArrayList();

    /* ================================================================
     * initXlet — BD-J lifecycle entry point
     * ================================================================ */
    public void initXlet(XletContext ctx) {
        try {
            DisableSecurityManagerAction.execute();
        } catch (Exception e) {}

        instance   = this;
        this.context = ctx;
        this.eq    = new EventQueue();
        this.scene = HSceneFactory.getInstance().getDefaultHScene();

        try {
            this.gui = new Screen(messages);
            this.gui.setSize(1920, 1080);
            this.scene.add(this.gui, "Center");

            UserEventRepository evRepo = new UserEventRepository("input");
            evRepo.addKey(BUTTON_X);
            evRepo.addKey(BUTTON_O);
            evRepo.addKey(BUTTON_UP);
            evRepo.addKey(BUTTON_DOWN);
            EventManager.getInstance().addUserEventListener(this, evRepo);

            /* Exploit thread */
            final InitXlet self = this;
            new Thread() {
                public void run() {
                    try {
                        runExploit(self);
                    } catch (Throwable t) {
                        self.scene.repaint();
                    }
                }
            }.start();

        } catch (Throwable t) {
            printStackTrace(t);
        }

        this.scene.validate();
    }

    /* ================================================================
     * runExploit — main exploit flow
     * ================================================================ */
    private static void runExploit(InitXlet self) {
        self.scene.repaint();
        console = new PrintStream(
            new MessagesOutputStream(messages, self.scene)
        );

        /* ── Banner ── */
        println("╔══════════════════════════════════════╗");
        println("║      HENloader MX  v" + VERSION + "           ║");
        println("║      by " + AUTHOR + "                   ║");
        println("╠══════════════════════════════════════╣");
        println("║  Based on HENloader LP by iaceene    ║");
        println("║  GoldHEN 2.4b18.7 by SiSTR0          ║");
        println("║  Poops exploit by theflow0           ║");
        println("║  Lapse exploit by Gezine             ║");
        println("╚══════════════════════════════════════╝");
        println("");

        System.gc();

        /* ── BD-J sandbox escape check ── */
        if (System.getSecurityManager() != null) {
            println("[!] Sandbox escape FAILED");
            println("[!] Firmware may be unsupported");
            println("[!] Try restarting the disc");
            return;
        }

        println("[+] Sandbox escaped successfully");

        /* ── Firmware detection ── */
        String fw = Helper.getCurrentFirmwareVersion();
        println("[*] Firmware : " + fw);

        /* ── Load kernel offsets ── */
        boolean supported = KernelOffset.initOffsets(fw);
        if (!supported) {
            println("[!] Firmware " + fw + " is NOT supported");
            println("[!] Supported: 9.00 – 13.52");
            return;
        }

        println("[+] Kernel offsets loaded for " + fw);
        println("[+] allproc  = 0x" + Long.toHexString(KernelOffset.allproc));
        println("[+] prison0  = 0x" + Long.toHexString(KernelOffset.prison0));
        println("[+] sysent   = 0x" + Long.toHexString(KernelOffset.sysent));
        println("");

        /* ── Determine available exploit chains ── */
        boolean poopsOnly = KernelOffset.usePoops(fw);
        boolean hasLapse  = !poopsOnly;

        /* ── Menu ── */
        mainLoop(fw, hasLapse, poopsOnly);
    }

    /* ================================================================
     * mainLoop — show menu and retry logic
     * ================================================================ */
    private static void mainLoop(String fw, boolean hasLapse, boolean poopsOnly) {
        byte lapseRetries = 0;

        while (true) {
            println("");
            println("── Select exploit ──────────────────────");

            if (hasLapse) {
                println("  X = Lapse  (recommended for " + fw + ")");
                println("  O = Poops");
            } else {
                println("  X = Poops  (only option for " + fw + ")");
            }

            println("────────────────────────────────────────");

            /* Wait for valid button */
            int btn = 0;
            while (true) {
                btn = pollInput();
                if (btn == BUTTON_X) break;
                if (btn == BUTTON_O && hasLapse) break;
            }

            boolean runLapse = (btn == BUTTON_X && hasLapse);

            if (runLapse) {
                /* ── Lapse chain ── */
                println("[*] Running Lapse exploit…");
                int ret = Lapse.main(console);
                if (ret == 0) {
                    onSuccess("Lapse", fw);
                    return;
                }
                lapseRetries++;
                if (ret <= -6 || lapseRetries >= 4) {
                    println("[!] Lapse fatal fail (" + ret + ") — REBOOT PS4");
                    return;
                }
                println("[!] Lapse failed (" + ret + ") — retry #" + lapseRetries);

            } else {
                /* ── Poops chain ── */
                println("[*] Running Poops exploit…");
                int ret = Poops.main(console);
                if (ret == 0) {
                    onSuccess("Poops", fw);
                    return;
                }
                println("[!] Poops fatal fail (" + ret + ") — REBOOT PS4");
                return;
            }
        }
    }

    /* ================================================================
     * onSuccess — called when exploit succeeds
     * ================================================================ */
    private static void onSuccess(String chain, String fw) {
        println("");
        println("╔══════════════════════════════════════╗");
        println("║         EXPLOIT SUCCESS!             ║");
        println("║                                      ║");
        println("║  Chain  : " + pad(chain, 26) + " ║");
        println("║  FW     : " + pad(fw, 26)    + " ║");
        println("║  Author : " + pad(AUTHOR, 26)+ " ║");
        println("╚══════════════════════════════════════╝");
        println("");
        println("[+] GoldHEN should now be active");
        println("[+] FTP / PKG install / Debug settings enabled");
        println("");
        println("    mansoor0x — HENloader MX v" + VERSION);
    }

    private static String pad(String s, int w) {
        while (s.length() < w) s = s + " ";
        return s.length() > w ? s.substring(0, w) : s;
    }

    /* ── Console helper ── */
    private static void println(String s) {
        if (console != null) console.println(s);
    }

    /* ================================================================
     * Xlet lifecycle
     * ================================================================ */
    public void startXlet() {
        gui.setVisible(true);
        scene.setVisible(true);
        gui.requestFocus();
    }

    public void pauseXlet()  { gui.setVisible(false); }

    public void destroyXlet(boolean b) {
        scene.remove(gui);
        scene = null;
    }

    /* ================================================================
     * Input handling
     * ================================================================ */
    public void userEventReceived(UserEvent e) {
        if (e.getType() != 401) return;
        int code = e.getCode();
        if (code == BUTTON_UP)   { gui.top += 270; scene.repaint(); return; }
        if (code == BUTTON_DOWN) { gui.top -= 270; scene.repaint(); return; }
        eq.put(Integer.valueOf(code));
    }

    public static void repaint() {
        if (instance != null) instance.scene.repaint();
    }

    public static int pollInput() {
        while (true) {
            Object o = instance.eq.get();
            if (o != null) return ((Integer) o).intValue();
            try { Thread.sleep(50); } catch (InterruptedException e) {}
        }
    }

    private void printStackTrace(Throwable t) {
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        if (console != null) console.print(sw.toString());
    }
}
