package org.bdj;

import org.bdj.api.NativeHelper;
import org.bdj.api.UnsafeHelper;
import org.bdj.external.KernelOffset;
import org.bdj.sandbox.SandboxEscape;

/**
 * Kernel.java — HENloader MX
 * mansoor0x · 2026
 *
 * Kernel interaction coordinator.
 *
 * Responsibilities:
 *   - Find kernel base (KASLR bypass)
 *   - Initialize KernelOffset for detected firmware
 *   - Coordinate sandbox escape and privilege escalation
 *   - Provide kernel r/w helpers for exploit chains
 */
public class Kernel {

    private static long kernelBase = 0L;
    private static boolean initialized = false;

    /* ================================================================
     * initializeKernelOffsets — called from InitXlet after FW detection
     * ================================================================ */
    public static void initializeKernelOffsets() {
        // Initialize native helper
        NativeHelper.init();
        UnsafeHelper.init();

        // Find kernel base
        kernelBase = NativeHelper.getKernelBase();
    }

    public static long getKernelBase()    { return kernelBase;   }
    public static boolean isInitialized() { return initialized;  }

    /* ================================================================
     * runSandboxEscape — privilege escalation coordinator
     * ================================================================ */
    public static int runSandboxEscape(java.io.PrintStream console) {
        if (kernelBase == 0) {
            console.println("[KRN] Cannot escalate — kernel base unknown");
            return -10;
        }
        return SandboxEscape.run(console, kernelBase);
    }

    /* ================================================================
     * readLong / writeLong / writeByte — kernel memory access
     * ================================================================ */
    public static long readLong(long addr) {
        return NativeHelper.readKernelLong(addr);
    }

    public static void writeLong(long addr, long val) {
        NativeHelper.writeKernelLong(addr, val);
    }

    public static void writeByte(long addr, byte val) {
        NativeHelper.writeKernelByte(addr, val);
    }

    /* ================================================================
     * writeNops — write N NOP bytes at kernel address
     * ================================================================ */
    public static void writeNops(long addr, int count) {
        for (int i = 0; i < count; i++) {
            NativeHelper.writeKernelByte(addr + i, (byte)0x90);
        }
    }

    /* ================================================================
     * writeRet1 — write "mov eax,1; ret" (always-true function)
     * ================================================================ */
    public static void writeRet1(long addr) {
        // B8 01 00 00 00 C3
        NativeHelper.writeKernelByte(addr,     (byte)0xB8);
        NativeHelper.writeKernelByte(addr + 1, (byte)0x01);
        NativeHelper.writeKernelByte(addr + 2, (byte)0x00);
        NativeHelper.writeKernelByte(addr + 3, (byte)0x00);
        NativeHelper.writeKernelByte(addr + 4, (byte)0x00);
        NativeHelper.writeKernelByte(addr + 5, (byte)0xC3);
    }

    /* ================================================================
     * writeRet0 — write "xor eax,eax; ret" (always-zero function)
     * ================================================================ */
    public static void writeRet0(long addr) {
        // 31 C0 C3
        NativeHelper.writeKernelByte(addr,     (byte)0x31);
        NativeHelper.writeKernelByte(addr + 1, (byte)0xC0);
        NativeHelper.writeKernelByte(addr + 2, (byte)0xC3);
    }
}
