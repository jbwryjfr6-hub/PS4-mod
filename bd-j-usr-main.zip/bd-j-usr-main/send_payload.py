#!/usr/bin/env python3
"""
send_payload.py — HENloader MX
mansoor0x · 2026

Sends GoldHEN.bin to the PS4 over TCP.
Run on your PC AFTER the disc is booted and you see
"[NET] Listening on port 9090" on screen.

Usage:
    python send_payload.py <PS4_IP> <payload.bin>
    python send_payload.py 192.168.1.100 GoldHEN.bin
"""

import sys, socket, os, time

PORT = 9090

def send(ip: str, path: str) -> None:
    size = os.path.getsize(path)
    print(f"  HENloader MX — Payload Sender")
    print(f"  Target : {ip}:{PORT}")
    print(f"  Payload: {path}  ({size:,} bytes / {size//1024} KB)")
    print()

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(35)

    print("  Connecting…")
    try:
        s.connect((ip, PORT))
    except Exception as e:
        print(f"  [!] Connection failed: {e}")
        print(f"      Boot the disc first, wait for [NET] message")
        sys.exit(1)

    # Wait for ACK
    try:
        ack = s.recv(1)
        if ack != b"\x01":
            print(f"  [!] Bad ACK from PS4: {ack.hex()}")
    except Exception:
        pass  # Some versions don't send ACK

    print("  Sending…")
    with open(path, "rb") as f:
        sent = 0
        start = time.time()
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            s.sendall(chunk)
            sent += len(chunk)
            pct = sent * 100 // size
            bar = "█" * (pct // 5) + "░" * (20 - pct // 5)
            elapsed = time.time() - start
            kbps = (sent // 1024) / elapsed if elapsed > 0 else 0
            print(f"\r  [{bar}] {pct:3d}%  {kbps:.0f} KB/s", end="", flush=True)

    s.close()
    print(f"\n  ✓  Done — {sent:,} bytes sent")
    print("  Check your PS4 screen for GoldHEN status")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(f"Usage: python {sys.argv[0]} <PS4_IP> <GoldHEN.bin>")
        sys.exit(1)
    send(sys.argv[1], sys.argv[2])
