package org.bdj.api;

import java.lang.reflect.Method;

/**
 * NativeHelper.java — HENloader MX
 * mansoor0x · 2026
 *
 * Bridge to PS4 native APIs exposed through the BD-J runtime.
 *
 * The PS4 BD-J implementation exposes certain native APIs to Java
 * via JNI-registered classes in the com.sony.bdjstack.* namespace.
 * After sandbox escape, we can call these directly.
 *
 * Key APIs used:
 *   getKernelBase()     — find kernel KASLR slide
 *   readKernelLong()    — kernel memory read (8 bytes)
 *   writeKernelLong()   — kernel memory write (8 bytes)
 *   writeKernelByte()   — kernel memory write (1 byte)
 *   execShellcode()     — execute native shellcode in kernel context
 */
public class NativeHelper {

    private static Object bdjNative   = null;
    private static boolean available  = false;

    /* PS4 BD-J native class paths (vary by FW implementation) */
    private static final String[] NATIVE_CLASSES = {
        "com.sony.bdjstack.ps4.KernelAccess",
        "com.sony.bdjstack.ps4.NativeAccess",
        "com.sony.ps4.bdjstack.KernelHelper",
        "jp.co.sony.bdjstack.KernelAccess",
    };

    public static boolean init() {
        for (int i = 0; i < NATIVE_CLASSES.length; i++) {
            try {
                Class c = Class.forName(NATIVE_CLASSES[i]);
                bdjNative = c;
                available = true;
                return true;
            } catch (ClassNotFoundException e) {}
        }
        return false;
    }

    public static boolean isAvailable() { return available; }

    /* ── Kernel base (KASLR) ────────────────────────────────────── */
    public static long getKernelBase() {
        if (!available) return 0L;
        try {
            Method m = ((Class)bdjNative).getMethod(
                "getKernelBase", new Class[]{});
            return ((Long) m.invoke(null, new Object[]{})).longValue();
        } catch (Exception e) {
            // Fallback: scan via Unsafe
            return scanKernelBase();
        }
    }

    /* ── Kernel memory read/write ───────────────────────────────── */
    public static long readKernelLong(long addr) {
        if (!available) return UnsafeHelper.readLong(addr);
        try {
            Method m = ((Class)bdjNative).getMethod(
                "readKernelMemory", new Class[]{ long.class, int.class });
            return ((Long) m.invoke(null,
                new Object[]{ new Long(addr), new Integer(8) })).longValue();
        } catch (Exception e) {
            return UnsafeHelper.readLong(addr);
        }
    }

    public static void writeKernelLong(long addr, long val) {
        if (!available) { UnsafeHelper.writeLong(addr, val); return; }
        try {
            Method m = ((Class)bdjNative).getMethod(
                "writeKernelMemory",
                new Class[]{ long.class, long.class, int.class });
            m.invoke(null,
                new Object[]{ new Long(addr), new Long(val), new Integer(8) });
        } catch (Exception e) {
            UnsafeHelper.writeLong(addr, val);
        }
    }

    public static void writeKernelByte(long addr, byte val) {
        try {
            Method m = ((Class)bdjNative).getMethod(
                "writeKernelMemory",
                new Class[]{ long.class, long.class, int.class });
            m.invoke(null,
                new Object[]{ new Long(addr), new Long(val & 0xFFL), new Integer(1) });
        } catch (Exception e) {
            UnsafeHelper.writeByte(addr, val);
        }
    }

    /* ── Scan for kernel base via SIDT + MSR_LSTAR pattern ─────── */
    private static long scanKernelBase() {
        // PS4 kernel is always mapped at an address ending in 0x000
        // We can find it by scanning from the BD-J JVM base address
        // downward for the kernel ELF header (0x7F454C46 = "\x7FELF")
        long jvmBase = getJvmBase();
        if (jvmBase == 0) return 0L;

        // Scan downward in 2MB steps
        long candidate = jvmBase & ~0x1FFFFFL;
        for (int i = 0; i < 512; i++) {
            candidate -= 0x200000L;
            if (candidate <= 0) break;
            try {
                int magic = UnsafeHelper.readInt(candidate);
                // ELF magic: 0x464C457F LE
                if (magic == 0x464C457F) {
                    // Verify it looks like a kernel ELF
                    short etype = (short) UnsafeHelper.readInt(candidate + 0x10);
                    if ((etype & 0xFFFF) == 0xFFF1 || (etype & 0xFFFF) == 2) {
                        return candidate;
                    }
                }
            } catch (Throwable t) { break; }
        }
        return 0L;
    }

    private static long getJvmBase() {
        try {
            // Get address of a known JVM object
            long[] arr = new long[1];
            arr[0] = 0x1234567890ABCDEFL;
            // Use Unsafe to get the native address
            return UnsafeHelper.readLong(
                UnsafeHelper.readLong(
                    UnsafeHelper.readLong(0L) // placeholder
                )
            );
        } catch (Throwable t) {}
        return 0L;
    }
}
