package org.bdj.api;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * UnsafeHelper.java — HENloader MX
 * mansoor0x · 2026
 *
 * Wraps sun.misc.Unsafe for direct memory access.
 * After sandbox escape, Unsafe gives us native memory read/write
 * which is the foundation of the kernel exploit.
 *
 * Key operations:
 *   readLong(addr)         — read 8 bytes from native address
 *   writeLong(addr, val)   — write 8 bytes to native address
 *   readInt(addr)          — read 4 bytes
 *   writeInt(addr, val)    — write 4 bytes
 *   writeByte(addr, val)   — write 1 byte
 *   allocateMemory(size)   — allocate native memory block
 *   freeMemory(addr)       — free native memory block
 *   copyMemory(src,dst,len)— copy native memory
 */
public class UnsafeHelper {

    private static Object unsafe      = null;
    private static Class  unsafeClass = null;

    // Cached method references
    private static Method m_getLong;
    private static Method m_putLong;
    private static Method m_getInt;
    private static Method m_putInt;
    private static Method m_getByte;
    private static Method m_putByte;
    private static Method m_allocate;
    private static Method m_free;
    private static Method m_copy;
    private static Method m_addressSize;

    private static boolean initialized = false;

    /* ── Initialize Unsafe ─────────────────────────────────────── */
    public static boolean init() {
        if (initialized) return true;
        try {
            unsafeClass = Class.forName("sun.misc.Unsafe");
            Field f = unsafeClass.getDeclaredField("theUnsafe");
            f.setAccessible(true);
            unsafe = f.get(null);

            // Cache all methods we'll use
            m_getLong    = unsafeClass.getMethod("getLong",
                               new Class[]{ long.class });
            m_putLong    = unsafeClass.getMethod("putLong",
                               new Class[]{ long.class, long.class });
            m_getInt     = unsafeClass.getMethod("getInt",
                               new Class[]{ long.class });
            m_putInt     = unsafeClass.getMethod("putInt",
                               new Class[]{ long.class, int.class });
            m_getByte    = unsafeClass.getMethod("getByte",
                               new Class[]{ long.class });
            m_putByte    = unsafeClass.getMethod("putByte",
                               new Class[]{ long.class, byte.class });
            m_allocate   = unsafeClass.getMethod("allocateMemory",
                               new Class[]{ long.class });
            m_free       = unsafeClass.getMethod("freeMemory",
                               new Class[]{ long.class });
            m_copy       = unsafeClass.getMethod("copyMemory",
                               new Class[]{ long.class, long.class, long.class });
            m_addressSize= unsafeClass.getMethod("addressSize",
                               new Class[]{});

            initialized = true;
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean isAvailable() { return initialized && unsafe != null; }

    /* ── Memory primitives ─────────────────────────────────────── */
    public static long readLong(long addr) {
        try {
            return ((Long) m_getLong.invoke(unsafe,
                new Object[]{ new Long(addr) })).longValue();
        } catch (Exception e) { return 0L; }
    }

    public static void writeLong(long addr, long val) {
        try {
            m_putLong.invoke(unsafe,
                new Object[]{ new Long(addr), new Long(val) });
        } catch (Exception e) {}
    }

    public static int readInt(long addr) {
        try {
            return ((Integer) m_getInt.invoke(unsafe,
                new Object[]{ new Long(addr) })).intValue();
        } catch (Exception e) { return 0; }
    }

    public static void writeInt(long addr, int val) {
        try {
            m_putInt.invoke(unsafe,
                new Object[]{ new Long(addr), new Integer(val) });
        } catch (Exception e) {}
    }

    public static byte readByte(long addr) {
        try {
            return ((Byte) m_getByte.invoke(unsafe,
                new Object[]{ new Long(addr) })).byteValue();
        } catch (Exception e) { return 0; }
    }

    public static void writeByte(long addr, byte val) {
        try {
            m_putByte.invoke(unsafe,
                new Object[]{ new Long(addr), new Byte(val) });
        } catch (Exception e) {}
    }

    public static long allocate(long size) {
        try {
            return ((Long) m_allocate.invoke(unsafe,
                new Object[]{ new Long(size) })).longValue();
        } catch (Exception e) { return 0L; }
    }

    public static void free(long addr) {
        try {
            m_free.invoke(unsafe, new Object[]{ new Long(addr) });
        } catch (Exception e) {}
    }

    public static void copy(long src, long dst, long len) {
        try {
            m_copy.invoke(unsafe,
                new Object[]{ new Long(src), new Long(dst), new Long(len) });
        } catch (Exception e) {}
    }

    public static int addressSize() {
        try {
            return ((Integer) m_addressSize.invoke(unsafe,
                new Object[]{})).intValue();
        } catch (Exception e) { return 8; }
    }
}
