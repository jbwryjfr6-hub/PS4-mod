package org.bdj;

import java.io.OutputStream;
import java.util.ArrayList;
import org.havi.ui.HComponent;

/**
 * MessagesOutputStream.java — HENloader MX
 * mansoor0x · 2026
 * (Based on original by iaceene/HENloader_Source)
 */
public class MessagesOutputStream extends OutputStream {

    private final ArrayList messages;
    private final HComponent scene;
    private final StringBuffer buf = new StringBuffer();

    public MessagesOutputStream(ArrayList messages, HComponent scene) {
        this.messages = messages;
        this.scene    = scene;
    }

    @Override
    public void write(int b) {
        char c = (char)(b & 0xFF);
        if (c == '\n') {
            flush_line();
        } else {
            buf.append(c);
        }
    }

    @Override
    public void write(byte[] b, int off, int len) {
        for (int i = off; i < off + len; i++) {
            write(b[i]);
        }
    }

    @Override
    public void flush() {
        if (buf.length() > 0) {
            flush_line();
        }
    }

    private void flush_line() {
        String line = buf.toString();
        buf.setLength(0);
        synchronized (messages) {
            /* Cap at 1000 lines to avoid OOM */
            if (messages.size() >= 1000) {
                messages.remove(0);
            }
            messages.add(line);
        }
        scene.repaint();
    }
}
