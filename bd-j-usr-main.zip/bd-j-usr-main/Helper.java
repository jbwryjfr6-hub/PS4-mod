package org.bdj;

/**
 * Helper.java — HENloader MX
 * mansoor0x · 2026
 *
 * Utility helpers for firmware detection and string formatting.
 * Reads PS4 firmware version via the BD-J system properties
 * that the PS4's BD-J implementation exposes.
 */
public class Helper {

    /**
     * Returns the current PS4 firmware version string, e.g. "13.00"
     * Uses the org.ps4.version system property exposed by Sony's BD-J.
     * Falls back to BD-J Java version string parsing if unavailable.
     */
    public static String getCurrentFirmwareVersion() {
        try {
            /* Primary: PS4-specific system property */
            String v = System.getProperty("org.ps4.version");
            if (v != null && !v.isEmpty()) return v.trim();

            /* Secondary: bd.version (some firmware revisions) */
            v = System.getProperty("bd.version");
            if (v != null && !v.isEmpty()) return v.trim();

            /* Tertiary: parse from BD-J java.version or bd.profile */
            v = System.getProperty("java.version");
            if (v != null && v.contains("PS4")) {
                /* e.g. "PS4-13.00" → "13.00" */
                int idx = v.indexOf("PS4-");
                if (idx >= 0) return v.substring(idx + 4).trim();
            }

        } catch (Exception e) {}

        return "unknown";
    }

    /**
     * Returns true if the given firmware string is in the 13.x range.
     */
    public static boolean is13x(String fw) {
        return fw != null && fw.startsWith("13.");
    }

    /**
     * Returns true if firmware is in the poops-only range (>= 12.50)
     */
    public static boolean isPoopsOnly(String fw) {
        if (fw == null) return false;
        return fw.equals("12.50") || fw.equals("12.52") || is13x(fw);
    }

    /**
     * Pads or truncates a string to exactly width chars.
     */
    public static String pad(String s, int width) {
        if (s == null) s = "";
        while (s.length() < width) s += " ";
        return s.length() > width ? s.substring(0, width) : s;
    }

    /**
     * Format a long as hex with 0x prefix.
     */
    public static String hex(long v) {
        return "0x" + Long.toHexString(v);
    }
}
