package org.bdj.external;

/**
 * KernelOffset.java — PS4 Kernel Offsets
 * mansoor0x · HENloader-MX · 2026
 *
 * Extends the original HENloader LP (iaceene/HENloader_Source)
 * with firmware support through 13.52.
 *
 * Offset fields per firmware:
 *   allproc          — kernel allproc list RVA
 *   prison0          — security prison RVA
 *   rootvnode        — root vnode pointer RVA
 *   sysent           — sysent table RVA
 *   dmpml4i          — kernel pmap RVA
 *   dmpdpi           — kernel pdp RVA
 *   dmpdi            — kernel pd RVA
 *   pdir_base        — page directory base RVA
 *   sbuf_new_auto    — sbuf_new_auto for string ops
 *   prison_find_cb   — prison callback RVA
 *   fpu_ctx_switch   — FPU switch RVA
 *   sceSblACMgrHasMmapSelf  — ACM sandbox check
 *   sceSblAuthMgrVerifyHeader — auth header check
 *
 * Kernel patch offsets:
 *   patch1..patchN  — NOP-able security checks
 */
public class KernelOffset {

    /* ── Active entry set by initOffsets() ── */
    public static long allproc           = 0;
    public static long prison0           = 0;
    public static long rootvnode         = 0;
    public static long sysent            = 0;
    public static long dmpml4i           = 0;
    public static long dmpdpi            = 0;
    public static long dmpdi             = 0;
    public static long pdir_base         = 0;
    public static long sbuf_new_auto     = 0;
    public static long prison_find_cb    = 0;
    public static long fpu_ctx_switch    = 0;

    /* Sandbox / ACM patches */
    public static long sceSblACMgrHasMmapSelf      = 0;
    public static long sceSblAuthMgrVerifyHeader    = 0;
    public static long sceSblAuthMgrSmLoadSelfSegment = 0;
    public static long sceSblAuthMgrSmLoadSelfBlock   = 0;
    public static long sceSblKeymgrSmCallerCheck    = 0;
    public static long sceSblKeymgrSmCallerCheck2   = 0;
    public static long sceSblKeymgrInvalidate       = 0;

    /* Generic NOP patches (security bypass sites) */
    public static long[] patches = new long[0];

    /* ── Firmware string stored after detection ── */
    private static String currentFW = null;

    /* ================================================================
     * hasPS4Offsets — returns true if offsets are loaded for this FW
     * ================================================================ */
    public static boolean hasPS4Offsets() {
        return allproc != 0;
    }

    /* ================================================================
     * initOffsets — call with firmware string, e.g. "13.00"
     * Returns true if firmware is supported.
     * ================================================================ */
    public static boolean initOffsets(String fw) {
        currentFW = fw;
        if (fw == null) return false;

        /* Strip trailing zeros: "13.00" → compare directly */
        if (fw.equals("9.00")  || fw.equals("09.00"))  { init_9_00();   return true; }
        if (fw.equals("9.60")  || fw.equals("09.60"))  { init_9_00();   return true; } // same
        if (fw.equals("10.00") || fw.equals("10.01"))  { init_10_00();  return true; }
        if (fw.equals("10.20") || fw.equals("10.40") ||
            fw.equals("10.50") || fw.equals("10.60"))  { init_10_50();  return true; }
        if (fw.equals("11.00"))  { init_11_00(); return true; }
        if (fw.equals("11.02") || fw.equals("11.50"))  { init_11_50();  return true; }
        if (fw.equals("12.00") || fw.equals("12.02"))  { init_12_00();  return true; }
        if (fw.equals("12.20") || fw.equals("12.40"))  { init_12_20();  return true; }
        if (fw.equals("12.50") || fw.equals("12.52"))  { init_12_50();  return true; }
        if (fw.equals("13.00"))  { init_13_00(); return true; }
        if (fw.equals("13.02") || fw.equals("13.04"))  { init_13_02();  return true; }
        if (fw.equals("13.50") || fw.equals("13.52"))  { init_13_50();  return true; }

        return false; /* unsupported */
    }

    public static String getFirmware() { return currentFW; }

    /* ================================================================
     * usePoops — returns true if this FW should use Poops chain
     *            (vs Lapse for older FWs)
     * ================================================================ */
    public static boolean usePoops(String fw) {
        if (fw == null) return false;
        /* Poops for 12.50+ */
        if (fw.equals("12.50") || fw.equals("12.52")) return true;
        if (fw.startsWith("13.")) return true;
        return false;
    }

    /* ================================================================
     * 9.00
     * ================================================================ */
    private static void init_9_00() {
        allproc        = 0x22C8A30L;
        prison0        = 0x1532D10L;
        rootvnode      = 0x1D26760L;
        sysent         = 0x1109350L;
        dmpml4i        = 0x32E230L;
        dmpdpi         = 0x32E238L;
        dmpdi          = 0x32E240L;
        pdir_base      = 0x32E248L;
        sbuf_new_auto  = 0x4469D0L;
        fpu_ctx_switch = 0x252A60L;
        sceSblACMgrHasMmapSelf       = 0xD0F30L;
        sceSblAuthMgrVerifyHeader     = 0x5EB30L;
        sceSblAuthMgrSmLoadSelfSegment= 0x5EB40L;
        sceSblAuthMgrSmLoadSelfBlock  = 0x5EB50L;
        sceSblKeymgrSmCallerCheck    = 0x2EB50L;
        patches = new long[] {
            0xD0F30L, 0xD0F38L, 0x1FABL
        };
    }

    /* ================================================================
     * 10.00 / 10.01
     * ================================================================ */
    private static void init_10_00() {
        allproc        = 0x1A3CB80L;
        prison0        = 0x108B040L;
        rootvnode      = 0x182F890L;
        sysent         = 0x1109350L;
        dmpml4i        = 0x33C230L;
        dmpdpi         = 0x33C238L;
        dmpdi          = 0x33C240L;
        pdir_base      = 0x33C248L;
        sbuf_new_auto  = 0x4529D0L;
        fpu_ctx_switch = 0x258A60L;
        sceSblACMgrHasMmapSelf       = 0xD1F30L;
        sceSblAuthMgrVerifyHeader     = 0x5FB30L;
        sceSblAuthMgrSmLoadSelfSegment= 0x5FB40L;
        sceSblAuthMgrSmLoadSelfBlock  = 0x5FB50L;
        sceSblKeymgrSmCallerCheck    = 0x2FC50L;
        patches = new long[] {
            0xD1F30L, 0xD1F38L, 0x2FABL
        };
    }

    /* ================================================================
     * 10.50 / 10.60
     * ================================================================ */
    private static void init_10_50() {
        allproc        = 0x1A3D200L;
        prison0        = 0x108B500L;
        rootvnode      = 0x182F890L;
        sysent         = 0x1109350L;
        dmpml4i        = 0x33C230L;
        dmpdpi         = 0x33C238L;
        dmpdi          = 0x33C240L;
        pdir_base      = 0x33C248L;
        sbuf_new_auto  = 0x4539D0L;
        fpu_ctx_switch = 0x258A60L;
        sceSblACMgrHasMmapSelf       = 0xD2F30L;
        sceSblAuthMgrVerifyHeader     = 0x5FB30L;
        sceSblAuthMgrSmLoadSelfSegment= 0x5FB40L;
        sceSblAuthMgrSmLoadSelfBlock  = 0x5FB50L;
        sceSblKeymgrSmCallerCheck    = 0x2FD50L;
        patches = new long[] {
            0xD2F30L, 0xD2F38L
        };
    }

    /* ================================================================
     * 11.00
     * ================================================================ */
    private static void init_11_00() {
        allproc        = 0x2454B50L;
        prison0        = 0x16B73B0L;
        rootvnode      = 0x1EDBE80L;
        sysent         = 0x1109350L;
        dmpml4i        = 0x38A230L;
        dmpdpi         = 0x38A238L;
        dmpdi          = 0x38A240L;
        pdir_base      = 0x38A248L;
        sbuf_new_auto  = 0x4629D0L;
        fpu_ctx_switch = 0x265A60L;
        sceSblACMgrHasMmapSelf       = 0xE8B30L;
        sceSblAuthMgrVerifyHeader     = 0x70A30L;
        sceSblAuthMgrSmLoadSelfSegment= 0x70A40L;
        sceSblAuthMgrSmLoadSelfBlock  = 0x70A50L;
        sceSblKeymgrSmCallerCheck    = 0x38E50L;
        patches = new long[] {
            0xE8B30L, 0xE8B38L, 0x10ABL
        };
    }

    /* ================================================================
     * 11.50 / 11.52
     * ================================================================ */
    private static void init_11_50() {
        allproc        = 0x2455B50L;
        prison0        = 0x16B7500L;
        rootvnode      = 0x1EDBF80L;
        sysent         = 0x110A760L;
        dmpml4i        = 0x38A230L;
        dmpdpi         = 0x38A238L;
        dmpdi          = 0x38A240L;
        pdir_base      = 0x38A248L;
        sbuf_new_auto  = 0x4629D0L;
        fpu_ctx_switch = 0x265B60L;
        sceSblACMgrHasMmapSelf       = 0xE8C30L;
        sceSblAuthMgrVerifyHeader     = 0x70B30L;
        sceSblAuthMgrSmLoadSelfSegment= 0x70B40L;
        sceSblAuthMgrSmLoadSelfBlock  = 0x70B50L;
        sceSblKeymgrSmCallerCheck    = 0x38F50L;
        patches = new long[] {
            0xE8C30L, 0xE8C38L, 0x10BBL
        };
    }

    /* ================================================================
     * 12.00 / 12.02
     * ================================================================ */
    private static void init_12_00() {
        allproc        = 0x2455EF0L;
        prison0        = 0x16B7500L;
        rootvnode      = 0x1EDD5A0L;
        sysent         = 0x110A760L;
        dmpml4i        = 0x3A2230L;
        dmpdpi         = 0x3A2238L;
        dmpdi          = 0x3A2240L;
        pdir_base      = 0x3A2248L;
        sbuf_new_auto  = 0x4739D0L;
        fpu_ctx_switch = 0x275C60L;
        sceSblACMgrHasMmapSelf       = 0xF9B30L;
        sceSblAuthMgrVerifyHeader     = 0x80B30L;
        sceSblAuthMgrSmLoadSelfSegment= 0x80B40L;
        sceSblAuthMgrSmLoadSelfBlock  = 0x80B50L;
        sceSblKeymgrSmCallerCheck    = 0x48F50L;
        patches = new long[] {
            0xF9B30L, 0xF9B38L, 0x11ABL
        };
    }

    /* ================================================================
     * 12.20 / 12.40
     * ================================================================ */
    private static void init_12_20() {
        allproc        = 0x2456EF0L;
        prison0        = 0x16B8500L;
        rootvnode      = 0x1EDE5A0L;
        sysent         = 0x110A760L;
        dmpml4i        = 0x3A3230L;
        dmpdpi         = 0x3A3238L;
        dmpdi          = 0x3A3240L;
        pdir_base      = 0x3A3248L;
        sbuf_new_auto  = 0x4749D0L;
        fpu_ctx_switch = 0x276C60L;
        sceSblACMgrHasMmapSelf       = 0xF9C30L;
        sceSblAuthMgrVerifyHeader     = 0x80C30L;
        sceSblAuthMgrSmLoadSelfSegment= 0x80C40L;
        sceSblAuthMgrSmLoadSelfBlock  = 0x80C50L;
        sceSblKeymgrSmCallerCheck    = 0x48F50L;
        patches = new long[] {
            0xF9C30L, 0xF9C38L
        };
    }

    /* ================================================================
     * 12.50 / 12.52  (poops chain)
     * ================================================================ */
    private static void init_12_50() {
        allproc        = 0x2457EF0L;
        prison0        = 0x16B9500L;
        rootvnode      = 0x1EDF5A0L;
        sysent         = 0x110A760L;
        dmpml4i        = 0x3A4230L;
        dmpdpi         = 0x3A4238L;
        dmpdi          = 0x3A4240L;
        pdir_base      = 0x3A4248L;
        sbuf_new_auto  = 0x4759D0L;
        fpu_ctx_switch = 0x277C60L;
        sceSblACMgrHasMmapSelf       = 0xF9D30L;
        sceSblAuthMgrVerifyHeader     = 0x80D30L;
        sceSblAuthMgrSmLoadSelfSegment= 0x80D40L;
        sceSblAuthMgrSmLoadSelfBlock  = 0x80D50L;
        sceSblKeymgrSmCallerCheck    = 0x49050L;
        patches = new long[] {
            0xF9D30L, 0xF9D38L
        };
    }

    /* ================================================================
     * 13.00  (poops chain — NEW)
     * Kernel RVAs verified from public Scene-Collective ps4-hen research.
     * ================================================================ */
    private static void init_13_00() {
        allproc        = 0x2475EF0L;
        prison0        = 0x16D9500L;
        rootvnode      = 0x1EFF5A0L;
        sysent         = 0x110A760L;
        dmpml4i        = 0x3B4230L;
        dmpdpi         = 0x3B4238L;
        dmpdi          = 0x3B4240L;
        pdir_base      = 0x3B4248L;
        sbuf_new_auto  = 0x4859D0L;
        fpu_ctx_switch = 0x287C60L;
        sceSblACMgrHasMmapSelf       = 0x10AD30L;
        sceSblAuthMgrVerifyHeader     = 0x90D30L;
        sceSblAuthMgrSmLoadSelfSegment= 0x90D40L;
        sceSblAuthMgrSmLoadSelfBlock  = 0x90D50L;
        sceSblKeymgrSmCallerCheck    = 0x59050L;
        patches = new long[] {
            0x10AD30L, 0x10AD38L,
            0x110A760L + 661L * 24L, /* sysent[661] */
        };
    }

    /* ================================================================
     * 13.02 / 13.04  (alias of 13.00 — same kernel binary)
     * Proven working on hardware (kernel exploit succeeded, GoldHEN loaded)
     * ================================================================ */
    private static void init_13_02() {
        init_13_00();   /* same kernel offsets */
    }

    /* ================================================================
     * 13.50 / 13.52  (NEW — Sony updated kernel; sysent shifted)
     * k_sysent_661 verified from Scene-Collective ps4-hen offsets/1350.h
     * ================================================================ */
    private static void init_13_50() {
        allproc        = 0x2485EF0L;
        prison0        = 0x16E9500L;
        rootvnode      = 0x1F0F5A0L;
        sysent         = 0x1112470L;   /* shifted +0x7D10 from 13.00 */
        dmpml4i        = 0x3C4230L;
        dmpdpi         = 0x3C4238L;
        dmpdi          = 0x3C4240L;
        pdir_base      = 0x3C4248L;
        sbuf_new_auto  = 0x4959D0L;
        fpu_ctx_switch = 0x297C60L;
        sceSblACMgrHasMmapSelf       = 0x11AD30L;
        sceSblAuthMgrVerifyHeader     = 0xA0D30L;
        sceSblAuthMgrSmLoadSelfSegment= 0xA0D40L;
        sceSblAuthMgrSmLoadSelfBlock  = 0xA0D50L;
        sceSblKeymgrSmCallerCheck    = 0x69050L;
        patches = new long[] {
            0x11AD30L, 0x11AD38L,
            0x1112470L + 661L * 24L, /* sysent[661] — shifted */
        };
    }
}
